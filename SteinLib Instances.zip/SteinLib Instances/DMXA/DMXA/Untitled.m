clear all; clc;

data=xlsread('dmxa1304.xlsx');
save data_dmxa1304;