clear all; clc;

data=xlsread('taq0751.xlsx');
save data_taq0751;