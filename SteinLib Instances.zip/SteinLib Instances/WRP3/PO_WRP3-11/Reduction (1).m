function [Rset,RL,foodpoint,EdgeBefore,EdgeAfter,FoodB,FoodA,STedge,N,fuseL,fusenum]=Reduction(solution,foodpoint,set,L);


%%%%%%%%%%%%%%%%%%%%%%%%% Reduction tests_SMT
N=length(set);
v=1e5;

FoodB=sum(foodpoint);
EdgeBefore=sum(sum(set))/2;
STedge=zeros(N); %%%% 1 means edge in SMT
fuseL=0; % disappeared length
fusenum=0; % disappeared number
exist=ones(N,1); % 1 means this vertex exist

% start the reduction
edgenuma=1; edgenumb=2; 

while edgenuma<edgenumb
    % calculate the number of existing edges before the reduction
     edgenumb=sum(sum(set))/2;
     
     %%% Degree 1-2 Test 
     % <Preprocessing the Steiner problem in graphs>
     [degree,dist,d_set,newL]=preparation(N,set,L); % preparation
     for i=1:N
         if foodpoint(i)==0 & degree(i)==1
             exist(i)=0;
         end
     end
     [N,set,L,exist,foodpoint]=updateN(N,set,L,exist,foodpoint); %%  updateN
     
     [degree,dist,d_set,newL]=preparation(N,set,L); % preparation
     for i=1:N
         if foodpoint(i)==1 & degree(i)==1  %%% <Solving Steiner tree problems in graphs to optimality>
             for j=1:N
                 if set(i,j)==1
                      exist(i)=0; foodpoint(j)=1; fuseL=fuseL+L(i,j); fusenum=fusenum+1;
                 end
             end
         end
     end
     [N,set,L,exist,foodpoint]=updateN(N,set,L,exist,foodpoint); %%  updateN

%      [degree,dist,d_set,newL]=preparation(N,set,L); % preparation
%      for i=1:N
%          if foodpoint(i)==0 & degree(i)==2  % this test may couple with foodpoint(i)==0 & degree(i)==1 to make mistakes
%              p=0;
%              for j=1:N
%                  if set(i,j)==1
%                      p=p+1;
%                      adjacent(p)=j; 
%                  end
%              end
%              exist(i)=0;
%              if set(adjacent(1),adjacent(2))==1
%                  L(adjacent(1),adjacent(2))=min(L(adjacent(1),adjacent(2)),L(i,adjacent(1))+L(i,adjacent(2)));
%                  L(adjacent(2),adjacent(1))=L(adjacent(1),adjacent(2));
%              else
%                  set(adjacent(1),adjacent(2))=1; set(adjacent(2),adjacent(1))=1; 
%                  L(adjacent(1),adjacent(2))=L(i,adjacent(1))+L(i,adjacent(2));
%                  L(adjacent(2),adjacent(1))=L(adjacent(1),adjacent(2));
%              end
%          end
%      end
%      [N,set,L,exist,foodpoint]=updateN(N,set,L,exist,foodpoint); %%  updateN
     
     
     %%%
     
     
     %%%%%%%%%%%%%%%%%%% special distance test SD
     % <An edge elimination test for the Steiner problem in graphs>
     [degree,dist,d_set,newL]=preparation(N,set,L); % preparation
     [s]=specialdistance(N,set,L,foodpoint,dist); %  calculate special distance s(i,:)
     for i=1:N
         for j=i:N
             if set(i,j)==1
                 if s(i,j)<L(i,j)
                     set(i,j)=0; set(j,i)=0;  % special distance test SD
                 end
             end
         end
     end
     %%%%%%%%
     
     %%%%%%%%%%%%%%%%%%% 	General Minimum Adjacency test
     %%%%  without the test of degree 0,  steinb1 can not be tested
     [degree,dist,d_set,newL]=preparation(N,set,L); % preparation
     for i=1:N
         if degree(i)==0
             exist(i)=0;
         end
     end
     [N,set,L,exist,foodpoint]=updateN(N,set,L,exist,foodpoint); %%  updateN
     %%%%%%%% <Some generalizations of the Steiner problem in graphs>
     [degree,dist,d_set,newL]=preparation(N,set,L); % preparation
     STedge=zeros(N); %%%% 1 means edge in SMT
     for k=1:N
         mini=0;
         mind=1e5;
         minimal=1e5;
         if foodpoint(k)==1 
             for i=1:N
                 if set(k,i)==1 & L(k,i)<mind
                     mini=i; mind=L(k,i);
                 end
             end
             for j=1:N
                 if set(k,j)==1 & j~=mini & L(k,j)<minimal
                     minimal=L(k,j);
                 end  
             end
             for mm=1:N
                 if foodpoint(mm)==1 & mm~=k
                     if dist(mm,mini)+mind<=minimal
                         STedge(mini,k)=1; STedge(k,mini)=1; foodpoint(mini)=1;
                     end
                 end
             end
         end
     end
     [set,L,N,foodpoint,fuseL,fusenum]=edgefuse(set,L,N,foodpoint,STedge,fuseL,fusenum); %%%%%  edge fusion
     %%%%%%%%%%%%%%%
     
     %%%% Vertices Nearer to K Test 
     %%%%%%%%  <Reduction tests for the Steiner problem in graphs>
     [degree,dist,d_set,newL]=preparation(N,set,L); % preparation
      for i=1:N
          for j=i:N
              if set(i,j)==1
                  for p=1:N
                      if foodpoint(p)==1 & dist(p,j)<newL(i,j) & dist(p,i)<newL(i,j)
                          set(i,j)=0; set(j,i)=0;
                      end
                  end
              end
          end
      end
     %%%%% 
     
     %%%% R1 test
     %%%%%%%%%%%  <Preprocessing the Steiner problem in graphs>
     [degree,dist,d_set,newL]=preparation(N,set,L); % preparation
     for i=1:N
         if foodpoint(i)==0
             for j=1:N
                 if foodpoint(j)==1
                     if dist(i,j)>solution
                         set(i,j)=0; set(j,i)=0;
                     end
                 end
             end
         end
     end
     %%%%
   
     

     edgenuma=0;  % calculate the number of existing edges after the reduction
     for i=1:N
         for j=i:N
             if set(i,j)==1
                 edgenuma=edgenuma+1;
             end
         end
     end 
end


Rset=set;
RL=L;
EdgeAfter=edgenuma;
FoodA=sum(foodpoint);



function [set,L,N,foodpoint,fuseL,fusenum]=edgefuse(set,L,N,foodpoint,STedge,fuseL,fusenum) %%%%%  edge fusion
v=1e5;
index=ones(N,2);  %  index(x,1)=1/0 means whether this column/row exists, index(x,2) means which column/row this column/row is fused by.
for m=1:N
    index(m,2)=m;
end
for i=1:N
    for j=i:N  % j>i   j fused by i
        if STedge(i,j)==1 % & foodpoint(i)+foodpoint(j)==2
            maxi=max(index(i,2),index(j,2));
            mini=min(index(i,2),index(j,2));
            if maxi~=mini
               for n=1:N
                     set(n,mini)=max(set(index(n,2),mini),set(index(n,2),maxi));  %  fuse maxi into mini
                     set(mini,n)=set(n,mini);
                     L(n,mini)=min(L(index(n,2),mini),L(index(n,2),maxi)); 
                     L(mini,n)=L(n,mini);
               end
               set(mini,mini)=0;
               L(mini,mini)=v;
               index(maxi,1)=0; % row maxi is not exist
               index(maxi,2)=mini;
               fuseL=fuseL+L(i,j);
               fusenum=fusenum+1;
               if foodpoint(maxi)==1
                   foodpoint(mini)=1;
               end
            else
               fuseL=fuseL+L(i,j);
               fusenum=fusenum+1;
            end
        end
    end
end
NN=sum(index(:,1));
newset=zeros(NN); newL=v*ones(NN); newfood=zeros(NN,1);
m=0;
for i=1:N
    if index(i,1)==1
        m=m+1; % row number
        newfood(m)=foodpoint(i);
        n=0;
        for j=1:N
            if index(j,1)==1
                n=n+1; % column number
                newset(m,n)=set(i,j); newL(m,n)=L(i,j);
            end
        end
    end
end
N=NN;
foodpoint=newfood;
set=newset;
L=newL;





function [N,set,L,exist,foodpoint]=updateN(N,set,L,exist,foodpoint) % remove vertices
     NN=sum(exist); % why sum(exist)~=NN  size(exist)>N
     newset=zeros(NN); newL=1e6*ones(NN); newfoodpoint=zeros(NN,1);
     m=0;
     for i=1:N
         if exist(i)==1
             m=m+1; % row number
             newfoodpoint(m)=foodpoint(i);
             n=0;
             for j=1:N
                 if exist(j)==1
                     n=n+1; % column number
                     newset(m,n)=set(i,j); newL(m,n)=L(i,j);
                 end
             end
         end
     end
     N=NN;
     set=newset;
     L=newL;
     foodpoint=newfoodpoint;
     exist=ones(NN,1); % 1 means this vertex exist



function [degree,dist,d_set,newL]=preparation(N,set,L)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% preparation
     v=1e5;
     degree=zeros(N,1);  % degree of vertex
     for i=1:N
         for j=1:N
             if set(i,j)==1
                 degree(i)=degree(i)+1; % calculate the degree
             end
         end
     end  
     d_set=zeros(N,N,N,N);
     dist=v*ones(N,N);
     newL=zeros(N);
     for i=1:N
        for j=1:N
            if set(i,j)==1
                newL(i,j)=L(i,j);
            end
        end
     end
     LL=sparse(newL);
     for i=1:N
         for j=i:N
                 [dist(i,j),path,pred]=graphshortestpath(LL,i,j); % the shortest path
                 dist(j,i)=dist(i,j);
                 leng=length(path);
                 for mm=1:(leng-1)
                     d_set(i,j,path(mm),path(mm+1))=1;d_set(i,j,path(mm+1),path(mm))=1;
                     d_set(j,i,path(mm),path(mm+1))=1;d_set(j,i,path(mm+1),path(mm))=1;
                 end
         end
     end
%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [s]=specialdistance(N,set,L,foodpoint,dist) %%%%%%%  calculate special distance s(i,:)
for i=1:N        
         sL=zeros(N,1);
         sL(i)=1;
         for j=1:N
             delta(j)=dist(i,j);
         end
         while sum(sL)~=N
             mm=0;
             for j=1:N
                 if foodpoint(j)==1 & sL(j)==0
                     if mm==0
                         sk=j;
                         minimal=delta(j);
                     end
                     if delta(j)<minimal
                         minimal=delta(j); sk=j;
                     end
                     mm=1;
                 end
             end
             sL(sk)=1;
             for j=1:N
                 if sL(j)==0
                     delta(j)=min(delta(j),max(delta(sk),dist(sk,j)));
                 end
                 if j>sk & delta(j)<=delta(sk)
                     sL(j)=1;
                 end
             end
             nn=0;
             for mm=1:N
                 if foodpoint(mm)==1 & sL(mm)==0;
                     nn=1;
                 end
             end
             if nn==0
                 sL=ones(N,1);
             end
         end
         s(i,:)=delta;
     end
