clear all; 
clc;

%%%%%%%%%%%%%%%%%%%%%%%%% Physarum Optimization constructs a network    (one sink, many sources)
data=xlsread('G101R.xlsx');
name='G101';
optimal=131;  %%% optimal length


N=data(1,1); % vertex number
edge_num=data(2,1); 
terminal_num=data(edge_num+6,1);
foodpoint=zeros(N,1);
for i=(edge_num+7):(edge_num+terminal_num+6)
    terminal=data(i,1);
    foodpoint(terminal)=1;
end
foodnum=sum(foodpoint); 
%%%
food=zeros(foodnum,1);
r=0;
for i=1:N
      if foodpoint(i)==1
          r=r+1;
          food(r)=i;  %%%%%%  the num r food is the num i vertice
      end
end
%%%%%%%%%%%%%
success=0; %%% success time
solution=optimal+1;

%%%%%%%%%%%%define flux
I=1e0;  %%%%%
kk=100;  %%% inner iteration times
cutoff=1e-3;   %%%% cutoff value of D
%%%%% evolution of conductivity
alpha=0.123;
sigma=1.0;
%%%%%length matrix, set matrix, initial conductivity matrix
v=1e7; %%% long distance
L=v*ones(N,N);%%%
set=zeros(N,N);%%%%%sets of adjacent points.   1 means it's adjacent, 0 means not
D=zeros(N,N);
edgevalue=ones(N,N);
for i=3:(edge_num+2)
    L(data(i,1),data(i,2))=data(i,3); L(data(i,2),data(i,1))=data(i,3);
    set(data(i,1),data(i,2))=1; set(data(i,2),data(i,1))=1;
    D(data(i,1),data(i,2))=1; D(data(i,2),data(i,1))=1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Reduction tests
[Rset,RL,foodpoint,EdgeBefore,EdgeAfter,FoodB,FoodA,STedge,N,fuseL]=Reduction(solution,foodpoint,set,L);
foodnum=sum(sum(foodpoint)); %%%
%%%%%%%%%%%%%%%%
Time=toc;
N
EdgeAfter
foodnum
fuseL
fusenum

     degree=zeros(N,1);  % degree of vertex
     for i=1:N
         for j=1:N
             if Rset(i,j)==1
                 degree(i)=degree(i)+1; % calculate the degree
             end
         end
     end
     error=0;
     for i=1:N
         if foodpoint(i)==1 & degree(i)==0
               error=error+1;
         end
     end
     error %%%  number of wrongly cut foodpoints                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          

save Rtest15;  %%%%  save data,  make sure the name is RIGHT!!!







