clear all; clc;

data=xlsread('mc13.xlsx');
save data_mc13;