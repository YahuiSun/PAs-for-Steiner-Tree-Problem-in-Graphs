clear all; clc;

data=xlsread('alue6179.xlsx');
save data_alue6179;