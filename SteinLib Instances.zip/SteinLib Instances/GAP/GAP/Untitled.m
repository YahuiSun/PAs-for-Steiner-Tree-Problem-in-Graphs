clear all; clc;

data=xlsread('gap3128.xlsx');
save data_gap3128;