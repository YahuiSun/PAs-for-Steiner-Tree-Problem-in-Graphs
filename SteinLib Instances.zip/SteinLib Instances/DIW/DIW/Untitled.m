clear all; clc;

data=xlsread('diw0523.xlsx');
save data_diw0523;