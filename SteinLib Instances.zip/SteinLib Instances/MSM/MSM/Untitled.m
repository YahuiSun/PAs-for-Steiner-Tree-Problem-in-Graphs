clear all; clc;

data=xlsread('msm3727.xlsx');
save data_msm3727;