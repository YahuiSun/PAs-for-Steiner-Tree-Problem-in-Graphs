clear all; clc;

data=xlsread('b18.xlsx');
save data_b18;