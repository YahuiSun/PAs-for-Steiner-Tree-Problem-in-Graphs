clear all; clc;

data=xlsread('world666.xlsx');
save data_world666;